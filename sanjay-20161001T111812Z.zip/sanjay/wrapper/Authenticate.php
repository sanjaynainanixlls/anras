<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//print_r(dirname(dirname(__FILE__)));exit();
include dirname(dirname(__FILE__)) . '/config/config.php';
class Authenticate {

    public static function authenticateUser($user, $pwd) {
        echo $query = "SELECT username FROM users WHERE username = '" . $user . "' AND password = '" . ($pwd) . "'";
        $result = queryRunner::doSelect($query);
        return $result;
    }

}

$obj = new Authenticate();
$obj->authenticateUser("admin", "admin#123");
?>