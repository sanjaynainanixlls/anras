<?php

session_start();
include dirname(dirname(__FILE__)) . '/config/config.php';
class CheckUser {

    private $postParams;

    public function execute() {
        $this->postParams = Functions::getPostParams();
        $AuthenticateObj = new Authenticate();
        $result = $AuthenticateObj->authenticateUser($this->postParams['username'], $this->postParams['pwd']);
        if (!empty($result)) {
            $_SESSION["user"] = $result[0][username];
            header("location: ../home.php");
        } else {
            $_SESSION['error'] = "Invalid Username or Password!";
            header("location: ../index.php");
        }
    }

}

$CheckUserObj = new CheckUser();
$CheckUserObj->execute();
?>
