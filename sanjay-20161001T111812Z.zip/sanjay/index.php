<html>
<head>
    <script src="js/jquery.js"></script>
    <link rel="stylesheet" type="text/css" href="css/login.css">
<title>Admin Login</title>
    
</head>
<body>

<div class="login-page">
  <div class="form">
      <form class="register-form" action="action/CheckUser.php">
      <input type="text" placeholder="name"/>
      <input type="password" placeholder="password"/>
      <input type="text" placeholder="email address"/>
      <button>create</button>
      <p class="message">Already registered? <a href="#">Sign In</a></p>
    </form>
    <form class="login-form">
      <input type="text" placeholder="username"/>
      <input type="password" placeholder="password"/>
      <button>login</button>
    </form>
  </div>
</div>

<script>

    $('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});
    
</script>
    
</body>
</html>