<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include_once (dirname(__FILE__) . "/connection.php");
include_once (dirname(dirname(__FILE__)) . "/common/Functions.php");
include_once (dirname(dirname(__FILE__)) . "/common/functions.common.php");
include_once (dirname(dirname(__FILE__)) . "/common/queryRunner.php");

?>